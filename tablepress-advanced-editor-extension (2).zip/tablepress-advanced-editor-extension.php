<?php
/**
 * Plugin Name: TablePress Advanced Editor Extension
 * Description: Extends the TablePress Advanced Editor modal by adding list formatting options (ordered and unordered lists).
 * Version: 1.0
 * Author: James Hawkins
 */

// Hook into the action that adds buttons to the TinyMCE editor.
add_filter( 'tablepress_editor_buttons', 'tpaee_add_list_buttons' );

/**
 * Add list buttons to the TablePress Advanced Editor.
 *
 * @param array $buttons The existing TinyMCE buttons.
 * @return array Modified TinyMCE buttons.
 */
function tpaee_add_list_buttons( $buttons ) {
    // Add 'bullist' for unordered list and 'numlist' for ordered list.
    $buttons[] = 'bullist';
    $buttons[] = 'numlist';
    
    return $buttons;
}

// Hook into the filter that initializes TinyMCE to modify its settings.
add_filter( 'tablepress_tinymce_init', 'tpaee_customize_tinymce' );

/**
 * Customize TinyMCE initialization to support list formatting.
 *
 * @param array $initArray TinyMCE init settings.
 * @return array Modified TinyMCE init settings.
 */
function tpaee_customize_tinymce( $initArray ) {
    // Customize the toolbar by adding the 'bullist' and 'numlist' buttons.
    if ( isset( $initArray['toolbar1'] ) ) {
        $initArray['toolbar1'] .= ',bullist,numlist';
    } else {
        $initArray['toolbar1'] = 'bullist,numlist';
    }

    return $initArray;
}

add_action( 'admin_enqueue_scripts', 'tpaee_enqueue_custom_script' );
function tpaee_enqueue_custom_script() {
    wp_add_inline_script( 'tablepress-admin', 'tinyMCE.PluginManager.add("example", function(editor, url) { editor.ui.registry.addButton("bullist", {text: "UL", icon: "unordered-list", onAction: function() { editor.execCommand("InsertUnorderedList"); }}); editor.ui.registry.addButton("numlist", {text: "OL", icon: "ordered-list", onAction: function() { editor.execCommand("InsertOrderedList"); }}); });', 'after' );
}
